
<div class="product">
                    <div class="button">
                        <div class="a"><a href="?page=add-product">Thêm sản phẩm</a></div>
                    </div>
                    <div class="product-list">
                        <?php
                        showproduct();
                        ?>
                    </div>
                </div>