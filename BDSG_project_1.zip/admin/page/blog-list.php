
<div class="product">
                    <div class="button">
                        <div class="a"><a href="?page=add-blog-detail">Thêm bài viết</a></div>
                    </div>
                </div>
                 <div class="show-blog">
       <div class="display-blog">
        <?php 
        show_blog_list();
        ?>
        </div>

       </div>
        
    </div>