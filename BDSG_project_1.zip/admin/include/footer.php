</div>
        </div>
    </div>


<script src="./js/script.js"></script>    
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.3.3/dist/chart.umd.min.js"></script>

<script src="./js/chart.js"></script>
</body>
</html>