
    <div class="cart-page container">
        <div class="row justify-content-between">
            <div class="cart d-flex flex-column col-8">
                <table class="table">
                    <thead>
                      <tr class="content-box">
                        <th scope="col">
                            <div class="cart-tile cart-item-width">
                                Sản phẩm
                            </div>
                        </th>
                        <th scope="col">
                            <div class="cart-tile">
                                số lượng
                            </div>
                        </th>
                        <th scope="col">
                            <div class="cart-tile">
                                Tổng
                            </div>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php
                            shoppingCart();
                        
            ?>
        </div>

    </div>
    
    <script src="./js/script.js"></script>