
<form action="" method="post" enctype="multipart/form-data" style="margin: 120px;">
  Select image to upload:
  <input type="file" name="fileToUpload" id="fileToUpload">
  <input type="button" class="demofetch" value="Upload Image" name="submit">
</form>

<?php

    // if(isset($_POST['submit']) && $_POST['submit']){
    //     if(uploadAvatar('fileToUpload') != '' && uploadAvatar('fileToUpload') != null){
    //         print_r(uploadAvatar('fileToUpload'));
    //     }
    // }
?>