 <main>
        <div class="banner-index">
          <img src="img/banner4.png" alt="" width="100%">
        </div>
        <div class="xemngay-index">
              <a href="#">Xem Ngay</a>
        </div>
        <div class="introduce-index">
            <div class="con1-index">
                <img src="img/anh7.jpg" alt="Giới thiệu chung" width="380px" height="600px">
                <div class="btn-index">
                    <button>Xem Ngay</button>
                </div>
            </div>
            <div class="con2-index">
                <img src="img/anh2.jpg" alt="Giới Thiệu Chung" width="380px" height="600px">
                <div class="btn-index">
                    <button>Xem Ngay</button>
                </div>
            </div>
            <div class="con3-index">
                <img src="img/anh5.jpg" alt="Giới Thiệu Chung" width="380px" height="600px">
                <div class="btn-index">
                    <button>Xem Ngay</button>
                </div>
            </div>
        </div>
        <div class="banner1-index">

            <div class="iframe">
                <iframe width="800" height="500" src="https://www.youtube.com/embed/1gTvEIpl8K0"
                    title="YouTube video player" frameborder="0"
                    allow="controls; autoplay=1 ; muted; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowfullscreen>
                </iframe>

            </div>
        </div>
        <div class="h1-index">
            <h1>SẢN PHẨM MỚI</h1>
        </div>
        <div class="ig-index"><img src="img/Screenshot 2023-06-02 124959.png" alt=""></div>
        <div class="product-index">

            <div class="products1-index">
                <div class="imgposi-index">
                    <img src="img/icon1.png" alt="" width="58px" height="58px">
                </div>
                <div class="imgapso-index ">
                    <img src="img/icon2.png" alt="" width="58px" height="35px">
                </div>
                <div class="img-index"><img onmouseover="this.src='img/b1.1.png'" onmouseout="this.src='img/b1.jpg'"
                        src="img/b1.jpg" alt="" width="100%" height="80%" /></div>
                <p>Áo Thun Nam Tay Ngắn In Ngực Years Of Love Form Fitted - 10S23TSS080</p>
                <span>299.000 đ</span>
                <div class="contai-index">
                    <a href="chitietsp.html">XEM THÔNG TIN CHI TIẾT</a>
                </div>

            </div>
            <div class="products2-index">
                <div class="imgposi-index">
                    <img src="img/icon1.png" alt="" width="58px" height="58px">
                </div>
                <div class="img-index">
                    <div class="img-index"><img onmouseover="this.src='img/b2.2.jpg'" onmouseout="this.src='img/b2.jpg'"
                            src="img/b2.jpg" alt="" width="100%" height="80%" /></div>
                </div>
                <p>Áo Thun Nam Tay Ngắn In Ngực Years Of Love Form Fitted - 10S23TSS080</p>
                <span>229.000 đ</span>
                <div class="contai-index">
                    <a href="#">XEM THÔNG TIN CHI TIẾT</a>
                </div>

            </div>
            <div class="products3-index">
                <div class="imgposi-index">
                    <img src="img/icon1.png" alt="" width="58px" height="58px">
                </div>
                <div class="imgapso-index ">
                    <img src="img/icon2.png" alt="" width="58px" height="35px">
                </div>
                <div class="img-index">

                    <div class="img-index"><img onmouseover="this.src='img/b3.3.jpg'" onmouseout="this.src='img/b3.jpg'"
                            src="img/b3.jpg" alt=""width="100%" height="80%"  /></div>
                </div>
                <p>Áo Thun Nam Tay Ngắn In Ngực Years Of Love Form Fitted - 10S23TSS080</p>
                <span>229.000 đ</span>
                <div class="contai-index">
                    <a href="#">XEM THÔNG TIN CHI TIẾT</a>
                </div>
            </div>
            <div class="products4-index">
                <div class="imgposi-index">
                    <img src="img/icon1.png" alt="" width="58px" height="58px">
                </div>
                <div class="imgapso-index ">
                    <img src="img/icon2.png" alt="" width="58px" height="35px">
                </div>
                <div class="img-index">
                    <div class="img-index"><img onmouseover="this.src='img/b4.4.jpg'" onmouseout="this.src='img/b4.jpg'"
                            src="img/b4.jpg" alt=""width="100%" height="80%"  /></div>
                </div>
                <p>Áo Thun Nam Tay Ngắn In Ngực Years Of Love Form Fitted - 10S23TSS080</p>
                <span>229.000 đ</span>
                <div class="contai-index">
                    <a href="#">XEM THÔNG TIN CHI TIẾT</a>
                </div>
            </div>
        </div>
        <div class="h1-index">
            <h1>ưu đãi đồng giá</h1>
        </div>
        <div class="ig-index"><img src="img/Screenshot 2023-06-02 124959.png" alt=""></div>
        <div class="product-index">

            <div class="products1-index">
                <div class="imgposi-index">
                    <img src="img/icon1.png" alt="" width="58px" height="58px">
                </div>
                <div class="imgapso-index ">
                    <img src="img/icon4.png" alt="" width="58px" height="60px">
                </div>
                <div class="img-index"><img onmouseover="this.src='img/c2.jpg'" onmouseout="this.src='img/c1.jpg'"
                        src="img/c1.jpg" alt="" width="100%" height="80%"  /></div>
                <p>
                    Áo Sơ Mi Kaki Nam Denim Tay Ngắn Họa Tiết Form Loose - 10S21DSH001</p>
                <span>229.000 đ </span>
                <p class="discout-index">400.000đ</p>
                <p class="quanty-index">-15%</p>

                <div class="contai-index">
                    <a href="#">XEM THÔNG TIN CHI TIẾT</a>
                </div>

            </div>
            <div class="products2-index">
                <div class="imgposi-index">
                    <img src="img/icon1.png" alt="" width="58px" height="58px">
                </div>
                <div class="imgapso-index ">
                    <img src="img/icon4.png" alt="" width="58px" height="60px">
                </div>
                <div class="img-index">
                    <div class="img-index"><img onmouseover="this.src='img/3.jpg'" onmouseout="this.src='img/a3.jpg'"
                            src="img/a3.jpg" alt="" width="100%" height="80%"  /></div>
                </div>
                <p>Áo Thun Nữ Cúp Ngực Trơn Form Fitted Crop - 10S22TTOW007</p>
                <span>229.000 đ</span>
                <p class="discout-index">400.000đ</p>
                <p class="quanty-index">-15%</p>
                <div class="contai-index">
                    <a href="#">XEM THÔNG TIN CHI TIẾT</a>
                </div>

            </div>
            <div class="products3-index">
                <div class="imgposi-index">
                    <img src="img/icon1.png" alt="" width="58px" height="58px">
                </div>
                <div class="imgapso-index ">
                    <img src="img/icon4.png" alt="" width="58px" height="60px">
                </div>
                <div class="img-index">

                    <div class="img-index"><img onmouseover="this.src='img/c4.jpg'" onmouseout="this.src='img/c3.jpg'"
                            src="img/c3.jpg" alt="" width="100%" height="80%"  /></div>
                </div>
                <p>Áo Thun Nam Tay Ngắn In Ngực Years Of Love Form Fitted - 10S23TSS080</p>
                <span>229.000 đ</span>
                <p class="discout-index">400.000đ</p>
                <p class="quanty-index">-15%</p>
                <div class="contai-index">
                    <a href="#">XEM THÔNG TIN CHI TIẾT</a>
                </div>
            </div>
            <div class="products4-index">
                <div class="imgposi-index">
                    <img src="img/icon1.png" alt="" width="58px" height="58px">
                </div>
                <div class="imgapso-index ">
                    <img src="img/icon4.png" alt="" width="58px" height="60px">
                </div>
                <div class="img-index">
                    <div class="img-index"><img onmouseover="this.src='img/c6.jpg'" onmouseout="this.src='img/c5.jpg'"
                            src="img/c5.jpg" alt=""width="100%" height="80%"  /></div>
                </div>
                <p>Áo Thun Nam Tay Ngắn In Ngực Years Of Love Form Fitted - 10S23TSS080</p>
                <span>229.000 đ</span>
                <p class="discout-index">400.000đ</p>
                <p class="quanty-index">-15%</p>

                <div class="contai-index">
                    <a href="#">XEM THÔNG TIN CHI TIẾT</a>
                </div>
            </div>
        </div>


        <div class="container-index">

            <div class="nam-index"><img src="img/a.png" alt="" width="609px" height="498px">
                <span class="xem-index"><a href="product.html">XEM NGAY</a></span>
            </div>
            <div class="nu-index"><img src="img/4.4.jpg" alt="" width="609px" height="498px">
                <span class="xem-index"><a href="productnu.html">XEM NGAY</a></span>
            </div>
        </div>

        <div class="h1-index">
            <h1>TIN THỜI TRANG</h1>
        </div>
        <div class="last-index">
            <div class="imglast1-index">
                <img src="img/1.jpg" alt="" width="396px" height="294px">
                <div class="boder-index"><a href="#">New Collection</a> <a href="#">New Collection</a></div>
                <div class="p-index">10 Years Of Love | Mix & Match Cùng Chiếc Áo Thun Mừng Sinh Nhật Routine 10 Tuổi</div>
                <div class="day-index">June 19, 2023</div>

            </div>
            <div class="imglast2-index">
                <img src="img/2.jpg" alt="" width="396px" height="294px">
                <div class="boder-index"><a href="#">Sự Kiện</a> </div>
                <div class="p-index">10 Years Of Love - Hành trình 10 năm với Thương hiệu Routine</div>
                <div class="day-index">June 19, 2023</div>
            </div>
            <div class="imglast3-index">
                <img src="img/11.jpg" alt="" width="396px" height="294px">
                <div class="boder-index"><a href="#">Sự Kiện</a> </div>
                <div class="p-index">Kết quả Minigame ĐUA TOP LẬT HÌNH - RINH QUÀ  | Lộ diện chủ nhân chiếc điện
                    thoại</div>
                <div class="day-index">June 19, 2023</div>
            </div>
        </div>

        <div class="eye-index"><a href="?page=blog">Xem Thêm</a></div>
    </main>