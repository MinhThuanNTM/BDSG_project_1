 <div class="container">
        <form class="form-login">
            <h1>login</h1>
            <div class="form-text">

                <input type="text" placeholder="Tên tài khoản" name="username" id="username">
            </div>
            <div class="form-text">

                <input type="password" placeholder="Mật khẩu" id="password">
            </div>
            <div class="form-text">

                <input type="password" placeholder="Nhập lại mật khẩu" id="newpassword">
            </div>
            <button type="submit">Đăng ký</button>
            <span>Bạn đã có tài khoản ? Đăng nhập <a href="./login.html">Tại đây</a></span>
        </form>
    </div>