 
 <div class="id-blog"><?php 
      if(isset($_GET['post_id'])){
        echo $_GET['post_id'];
      }
    ?></div>
 <main>
    <div class="h1-blog">
      <h2>.</h2>
    </div>
    <div class="blogrow-blog">
      <div class="blofcolleft-blog">
        <div class="blog-xuhuong">
          <div class="trend"><a href="#">Xu Hướng Thời trang</a></div>
          <div class="discover"><a href="#">Khám Phá</a></div>
        </div>
        
      </div>
      <div class="blofcolright-blog">
        <h3>Tag Bài Viết</h3>
        <div class="span-blog">
          <span><a href="#">Xu Hướng Thời Trang</a></span>
          <span><a href="#">Mix & Mach</a></span>
          <span><a href="#">Khám Phá</a></span>
          <span><a href="#">Khuyến Mãi</a></span>
          <span><a href="#">Sự Kiện</a></span>
          <span><a href="#">Chất Liệu</a></span>
          <span><a href="#">New Collection</a></span>
          <span><a href="#">Form Dáng</a></span>
          <span><a href="#">Cách Bảo Quản</a></span>
        </div>
        <h3>Sản Phẩm Mới</h3>
        <div class="product-new-blog">
          <div id="carouselExampleControlsNoTouching" class="carousel slide" data-touch="false" data-interval="false">
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src="img/blog10.jpg" class="d-block w-100" alt="..." />
              </div>
              <div class="carousel-item">
                <img src="img/blog9.jpg" class="d-block w-100" alt="..." />
              </div>
              <div class="carousel-item">
                <img src="img/blog8.jpg" class="d-block w-100" alt="..." />
              </div>
              <div class="carousel-item">
                <img src="img/blog7.jpg" class="d-block w-100" alt="..." />
              </div>
            </div>
            <button class="carousel-control-prev" type="button" data-target="#carouselExampleControlsNoTouching"
              data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-target="#carouselExampleControlsNoTouching"
              data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </button>
          </div>
        </div>
        <h3>Bài Viết Mới</h3>
        <div class="flex-cha-blog">
          <div class="flex-blog">
            <img src="img/blog1.jpg" width="115px" height="77px" alt="" />
            <p>
              SHARING LOVE | Sharing Sport Energy - Trao Quà Tặng Gửi Yêu
              Thương
            </p>
          </div>
          <div class="day-blog">12.07.2023</div>
        </div>
        <div class="flex-cha-blog">
          <div class="flex-blog">
            <img src="img/blog2.jpg" width="115px" height="77px" alt="" />
            <p>
              Sportswear là gì? Chất liệu làm nên những bộ sportswear cao cấp
            </p>
          </div>
          <div class="day-blog">12.07.2023</div>
        </div>
        <div class="flex-cha-blog">
          <div class="flex-blog">
            <img src="img/blog3.jpg" width="115px" height="77px" alt="" />
            <p>
              Chất liệu Tencel là gì? Vải Tencel có thân thiện môi trường?
            </p>
          </div>
          <div class="day-blog">12.07.2023</div>
        </div>
        <div class="flex-cha-blog">
          <div class="flex-blog">
            <img src="img/blog4.jpg" width="115px" height="77px" alt="" />
            <p>
              10 kiểu áo sơ mi nam đẹp, chuẩn men nhất 2023
            </p>
          </div>
          <div class="day-blog">12.07.2023</div>
        </div>
        <div class="flex-cha-blog">
          <div class="flex-blog">
            <img src="img/blog5.jpg" width="115px" height="77px" alt="" />
            <p>
              Gợi ý cách phối đồ cùng quần kaki nam ống đứng đa dạng ấn
            </p>
          </div>
          <div class="day-blog">12.07.2023</div>
        </div>
        <div class="flex-cha-blog">
          <div class="flex-blog">
            <img src="img/blog6.jpg" width="115px" height="77px" alt="" />
            <p>
              Gợi ý 5 kiểu quần kaki nữ trẻ trung được giới trẻ lăng xê
            </p>
          </div>
          <div class="day-blog">12.07.2023</div>
        </div>
        <div class="flex-cha-blog">
          <div class="flex-blog">
            <img src="img/banner4.png" width="115px" height="77px" alt="" />
            <p>
              Kết quả Minigame ĐUA TOP LẬT HÌNH - RINH QUÀ SINH NHẬT | Lộ
            </p>
          </div>
          <div class="day-blog">12.07.2023</div>
        </div>
      </div>
    </div>

  </main>
