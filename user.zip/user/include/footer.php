<footer>
        <div class="footer">
            <div class="fterlast1">
                <div class="imgg"><img src="img/logoback.png" alt=""></div>
                <div class="las">CÔNG TY TNHH ROUTINE VIETNAM</div>
                <div class="las1">Mã Số Thuế: 0106486365</div>
                <div class="las1">Văn Phòng: Tầng 8 tòa nhà Lê Đình, 11Bis Nguyễn Gia Thiều,
                    phường Võ Thị Sáu, quận 3, TP HCM.</div>
                <div class="las">THAM GIA BẢNG TIN CỦA CHÚNG TÔI</div>
                <div class="iconn"><img src="img/icon5.png" alt=""></div>
            </div>
            <div class="fterlast2">
                <div class="las">CÔNG TY</div>
                <div class="menu">
                    <div><a href="#">Giới thiệu về ROUTINE</a></div>
                    <div><a href="#">Tuyển Dụng</a></div>
                    <div><a href="#">Tin Thời Trang</a></div>
                    <div><a href="#">Hợp Tác Nhượng Quyền</a></div>
                    <div><a href="#">Liên Hệ</a></div>
                </div>
                <div class="las">THAM GIA BẢNG TIN CỦA CHÚNG TÔI</div>

                <div class="iconn"><img src="img/icon6.png" alt=""></div>
            </div>
            <div class="fterlast3">
                <div class="las">CHÍNH SÁCH KHÁCH HÀNG</div>
                <div class="menu">
                    <div><a href="#">Chính sách khách hàng thân thiết</a></div>
                    <div><a href="#">Chính sách đổi trả</a></div>
                    <div><a href="#">Chính sách bảo hành</a></div>
                    <div><a href="#">Chính sách bảo mật</a></div>
                    <div><a href="#">Câu hỏi thường gặp</a></div>
                    <div><a href="#">Hướng dẫn mua hàng online</a></div>
                    <div><a href="#">Hướng dẫn kiểm tra hạng thẻ thành viên</a></div>
                </div>
            </div>

            <div class="fterlast4">
                <div class="las">CHÍNH SÁCH KHÁCH HÀNG</div>
                <div class="loco">CỬA HÀNG THỨ 34</div>
                <div class="lass">F15 tầng 1 AEON Mall Tân Phú, 30 Bờ Bao Tân Thắng, Phường Sơn Kỳ, TP Hồ Chí Minh</div>
                <div class="loco">CỬA HÀNG THỨ 33</div>
                <div class="lass">F15 tầng 1 AEON Mall Tân Phú, 30 Bờ Bao Tân Thắng, Phường Sơn Kỳ, TP Hồ Chí Minh</div>
                <div class="loco">CỬA HÀNG THỨ 32</div>
                <div class="lass">192 - 194 Hoa Lan, Phường 2, Quận Phú Nhuận, TP Hồ Chí Minh</div>
            </div>
        </div>
        <div class="bdsg">@2023 BIỆT ĐỘNG SÀI GÒN</div>
    </footer>
    <script src="js/userID.js"></script>
    <script src="js/login.js"></script>
    <script src="js/script.js"></script>
    <script src="./js/set-bg.js"></script>
    <script src="./js/blog.js"></script>
    <script src="./js/show-product.js"></script>
    <script
      src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"
      integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct"
      crossorigin="anonymous"
    ></script>
</body>

</html>