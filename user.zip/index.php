<?php
    
    header('Location: ./user');
?>